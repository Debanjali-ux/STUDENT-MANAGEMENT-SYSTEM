<?php
    include("user_dbconnection.php");
    
    if($_SERVER["REQUEST_METHOD"] == "POST") {
        // username and password sent from form 
        
        $myusername = mysqli_real_escape_string($conn,$_POST['username']);
        $mypassword = mysqli_real_escape_string($conn,$_POST['password']); 
        $encpassword=md5($mypassword);
        
       
        $sql = "SELECT * FROM `newuser` WHERE userid='$myusername' and Password='$encpassword' ";
        
        $result = mysqli_query($conn,$sql);
        
        $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      //$active = $row['active'];
      
      $count = mysqli_num_rows($result);
      
       
      // If result matched $myusername and $mypassword, table row must be 1 row
	
      /*if($count == 1) {
          
         $_SESSION['login_user'] = $myusername;
        
         header("location:STUDENT/dashboard.php");
      }else {
         $error = "Your Login Name or Password is invalid";
         
         
         
      }*/

      if($count<1)
      {
          ?>
          <script>
               alert("Wrong Username or Password!!!");
               window.open('index.php','_self');
          </script>
          <?php
      }
      else
      { 
        session_start();
        $_SESSION['login_user'] = $myusername;


         //last login update
            $uid=$_SESSION['login_user'];
            $sql1="UPDATE newuser set last_login=CURRENT_TIMESTAMP WHERE userid='$uid' ";
            $result1 = mysqli_query($conn,$sql1);

        header("location:STUDENT/dashboard.php");
      }
   }
?>



<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <title>STUDENT MANAGEMENT SYSTEM</title>
   <link href="CSS/login.css" rel="stylesheet" type=text/css>
</head>

<body>
    
         <div class="logo"> 
            <h1 align="center">STUDENT MANAGEMENT SYSTEM</h1>
         </div>
          

          <div class="bar">
            <marquee><b>REGISTER OR LOGIN</b></marquee>
         </div>
         
         
         <div class="container" >
            <form method="post">
            
        
                <h2 align="center"><u>USER LOGIN</u></h2><br><br>
                <label for="username">USERNAME:</label>
                <input type="text" id="username" name="username" placeholder="ENTER USERNAME" required="true"><br><br>
                <label for="password">PASSWORD:</label>
                <input type="text" id="password" name="password" placeholder="ENTER PASSWORD" required="true"><br>
                <small id="emailHelp" class="form-text text-muted">Password must contain atleast one upper case letter,atleast one number and atleast
                   eight characters long.
                </small><br>
               
                <input type="submit" type="submit" class="btn btn-primary"  value="Login" name='Login' id="Login"/>
                <button type="button" class="btn btn-success" name="sign_up" onclick="createAccount()" >Sign Up</button>


            </form>
        </div>

    

    



<script src="js/index.js"></script>
<!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src=" https://code.jquery.com/jquery-3.4.1.slim.min.js " integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n " crossorigin="anonymous "></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js " integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo " crossorigin="anonymous "></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js " integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6 " crossorigin="anonymous "></script>

</body>

</html>

