-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 26, 2020 at 06:16 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `university`
--

-- --------------------------------------------------------

--
-- Table structure for table `class`
--

CREATE TABLE `class` (
  `Class` int(11) NOT NULL,
  `No_of_sections` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `class`
--

INSERT INTO `class` (`Class`, `No_of_sections`) VALUES
(1, 2),
(2, 4),
(3, 3),
(4, 1),
(5, 2);

-- --------------------------------------------------------

--
-- Table structure for table `newuser`
--

CREATE TABLE `newuser` (
  `id` int(11) NOT NULL,
  `userid` varchar(255) NOT NULL,
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phnNo` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `section` varchar(255) NOT NULL,
  `image` text NOT NULL,
  `last_login` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `newuser`
--

INSERT INTO `newuser` (`id`, `userid`, `fname`, `lname`, `email`, `phnNo`, `address`, `Password`, `class`, `section`, `image`, `last_login`) VALUES
(24, 'STU8777094978', 'Dipayan', 'Roy', 'dipayan@gmail.com', '8777094978', 'Uttarpara', '9bd737db7166efa5f810f049ca39e550', '2', 'B', 'dipayan.jpg', '2020-04-26 20:53:13'),
(25, 'STU8077094978', 'Sristhi', 'Sen', 'sristhi@gmail.com', '8077094978', 'Sonarpur', '9bd737db7166efa5f810f049ca39e550', '3', 'B', 'Sristhi.jpg', '2020-04-26 20:43:39'),
(26, 'STU8177094978', 'Kuntal', 'Das', 'kuntal@gmail.com', '8177094978', 'Patuli', '9bd737db7166efa5f810f049ca39e550', '4', 'A', 'Kuntal.jpg', '0000-00-00 00:00:00'),
(27, 'STU8277094978', 'Shrinwanti', 'Ray', 'shrinwanti@gmail.com', '8277094978', 'Patuli', '9bd737db7166efa5f810f049ca39e550', '3', 'A', 'Shrinwanti.jpg', '2020-04-26 21:05:50'),
(28, 'STU8377094978', 'Jewel', 'Chakraborty', 'jewel@gmail.com', '8377094978', 'Bhowanipore', '9bd737db7166efa5f810f049ca39e550', '5', 'A', 'JEWEL_DP.jpg', '0000-00-00 00:00:00'),
(29, 'STU8477094978', 'Anirban', 'Patra', 'patra@gmail.com', '8477094978', 'Sokher Bajar', '9bd737db7166efa5f810f049ca39e550', '2', 'D', 'patra.jpg', '0000-00-00 00:00:00'),
(30, 'STU8577094978', 'Debprotim', 'Chakraborty', 'debprotim@gmail.com', '8577094978', 'Tollygunge', '9bd737db7166efa5f810f049ca39e550', '1', 'B', 'debprotim.jpg', '0000-00-00 00:00:00'),
(31, 'STU8677094978', 'Debanjali', 'Mitra', 'debanjali@gmail.com', '8677094978', 'Barasat', '9bd737db7166efa5f810f049ca39e550', '4', 'A', 'Debanjali.jpg', '0000-00-00 00:00:00'),
(32, 'STU8877094978', 'Anarpit', 'Ray', 'anarpit@gmail.com', '8877094978', 'Kudghat', '9bd737db7166efa5f810f049ca39e550', '2', 'C', 'anarpit.jpg', '2020-04-26 21:03:36');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `class`
--
ALTER TABLE `class`
  ADD PRIMARY KEY (`Class`);

--
-- Indexes for table `newuser`
--
ALTER TABLE `newuser`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `newuser`
--
ALTER TABLE `newuser`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
