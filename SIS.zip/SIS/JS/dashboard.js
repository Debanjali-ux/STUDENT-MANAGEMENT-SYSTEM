function myprofile()
{
    window.location.href= "profile.php";
}