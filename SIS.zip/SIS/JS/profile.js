function myedit()
{
    window.location.href = "../STUDENT/edit.php";

}
