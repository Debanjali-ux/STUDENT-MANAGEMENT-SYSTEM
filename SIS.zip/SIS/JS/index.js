
function createAccount()
{
    window.location.href = "STUDENT/create_account.php";

}

