<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <title>STUDENT MANAGEMENT SYSTEM</title>
   <link href="../CSS/create_account.css" rel="stylesheet" type=text/css>
</head>

<body>
         <div class="logo"> 
            <h1 align="center">STUDENT MANAGEMENT SYSTEM</h1>
         </div>

         <form name="myForm" action="create_account.php"  method="post" id="myForm" enctype="multipart/form-data">
            <div class="container" >
        
            <div class="row">
                <div class="col-12 offset-3">
                    <h1>CREATE ACCOUNT</h1>
                </div>
            </div>

            <div class="row">
                <div class="col">
                    <input type="text" class="form-control" id="firstName" name="firstName"  placeholder="Enter First Name" required="true">
                </div>
                <div class="col">
                    <input type="text" class="form-control" id="lastName" name="lastName" placeholder="Enter Last Name"  required="true"><br>
                </div>
            </div>

            <div class="row">
                <div class="col">

                    <input type="text" class="form-control" id="email" name="email" placeholder="Enter Email Address" required="true">
                </div>
                <div class="col">
                    <input type="text" class="form-control" id="phoneNo" name="phnNo" placeholder="Enter Phone No."  required="true"><br>
                </div>
                
            </div>
            
            <div class="row">
                <div class="col">
                    <input type="text" class="form-control" id="address" name="address" placeholder="Enter Your Address" required="true"><br>
                </div>
            </div>

           

            <div class="form-row">
                <div class="form-group col-md-6">
                    
                     <select class="form-control" id="sclass" name="sclass" required="true" >
                         <option value="" hidden>Select the Class</option>
                         <option value="1">One</option>
                         <option value="2">Two</option>
                         <option value="3">Three</option>
                         <option value="4">Four</option>
                         <option value="5">Five</option>
                    </select>
                </div>
                
                <div class="form-group col-md-6">
                    <select class="form-control" id="ssection" name="ssection" required="true" disabled>
                                    <option selected>Select the Section</option>

                    </select>
                </div>
            </div>

            

            <div class="row">
                <div class="col">

                    <input type="password" class="form-control" id="pwd" name="pwd" placeholder="Enter Password" required="true" >
                </div>
                <div class="col">
                    <input type="password" class="form-control" id="confirmPwd" name="confirmPwd" placeholder="Confirm Password"  required="true" ><br>
                </div>
            </div>

            <div class="form-group col-md-6">
            <label for="img"><b>Upload image:</b></label>&nbsp;
            <input type="file"  id="img" name="img" required="true" ><br>
            </div>
             
        <div class="row">
            <div class="col-10">
              <input type="submit" class="btn btn-primary" onclick="return register();" value="Submit" name='submit' id="submit"/>
            
            
              <button type="button" class="btn btn-success" id="goBack" onclick="gotologin()">Go Back</button>
            </div>
        </div>

            
               

           </div> 
         </form>
          
         
<!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    
    <!--<script src=" https://code.jquery.com/jquery-3.4.1.slim.min.js " integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n " crossorigin="anonymous "></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js " integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo " crossorigin="anonymous "></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js " integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6 " crossorigin="anonymous "></script>-->

    <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>


    <script src="../js/create_account.js"></script>
    <script src="../js/custom.js"></script>
</body>

</html>

<?php
   $filename="";
   $extension="";
   if(isset($_POST['submit']))
     {
      
      $fname=$_POST['firstName'];
      $lname=$_POST['lastName'];
      $email=$_POST['email'];
      $phnNo=$_POST['phnNo'];
      $address=$_POST['address'];
      $pwd=md5($_POST['pwd']);
      $confirmPwd=md5($_POST['confirmPwd']);
      $class=$_POST['sclass'];
      $section=$_POST['ssection'];
      $imagename=$_FILES['img']['name'];
      $tempname=$_FILES['img']['tmp_name'];
      $file=explode(".",$imagename);
      $fileSize= $_FILES['img']['size'] ;
      if( $fileSize!=0)
      {   
         
          $filename=$file[0];
          $extension=$file[1];
      }
      
      $allowedExtensions=array("gif","png","bmp","jpeg","jpg");
      
      

     include('../user_dbconnection.php');
     
     $sql1="SELECT * FROM `newuser` WHERE email='$email' and phnNo='$phnNo' ";
     $result1=mysqli_query($conn,$sql1);
     $run1=mysqli_num_rows( $result1);
     $sql2="SELECT * FROM `newuser` WHERE email='$email' ";
     $result2=mysqli_query($conn,$sql2);
     $run2=mysqli_num_rows( $result2);
     $sql3="SELECT * FROM `newuser` WHERE  phnNo='$phnNo' ";
     $result3=mysqli_query($conn,$sql3);
     $run3=mysqli_num_rows( $result3);
     if($run1==1)
     {
       ?>
       <script>
           alert("The email and Phone number already exists...Please try to register with new email and number!!!");
       </script>
       <?php
     }
     else if($run2==1)
     {
       ?>
       <script>
           alert("The email already exists...Please try to register with a new email!!!");
       </script>
       <?php
     }
     else if($run3==1)
     {
       ?>
       <script>
           alert("The Phone Number already exists...Please try to register with a new number!!!");
       </script>
       <?php
     }


     else{
   if(preg_match("/^[A-Za-z]+$/",$_POST['firstName']))
     {
        if(preg_match("/^[A-Za-z]+$/",$_POST['lastName']))
          {
             if(preg_match("/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/",$_POST['email']))
               {
                if(preg_match("/^(?:(?:\+|0{0,2})91(\s*[\ -]\s*)?|[0]?)?[789]\d{9}|(\d[ -]?){10}\d$/",$_POST['phnNo']))   
                   {
                    if(preg_match("/.+$/",$_POST['address']))
                        { 
                         if($_POST['sclass']!="")
                         {
                          if($_POST['ssection']!="select")
                           {
                               if(preg_match("/^(?=.*?[A-Z])(?=.*?[0-9]).{8,}$/",$_POST['pwd']))
                            {
                                if($_POST['confirmPwd']==$_POST['pwd'])
                               { 
                                 if(in_array($extension,$allowedExtensions))
                                   {  
                                       $userid="STU" . $phnNo;
                                       move_uploaded_file($tempname,"../STD_IMG/$imagename");
                                       $sql="INSERT INTO `newuser`(`userid`,`fname`, `lname`,`email`,`phnNo`,`address`,`Password`,`class`,`section`,`image`) 
                                       VALUES ('$userid','$fname','$lname','$email','$phnNo','$address','$pwd','$class','$section','$imagename')";
                                       $result = mysqli_query($conn,$sql);
                                       ?>
                                       <script>
                                          alert("Successfully Registered");
                                          window.location.href="../index.php";
                                       </script>
                                       <?php
                                   }
                                }
                            }
                        }
                   }
               }
          }
     }}
    }}

 }
?>