<html>
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
     
    <title>STUDENT MANAGEMENT SYSTEM</title>
    <link href="../CSS/dashboard.css" rel="stylesheet" type=text/css>
   
</head>
<body>
<div class="logo"> 
            <h1 align="center">STUDENT MANAGEMENT SYSTEM</h1>
 </div>

 <?php 
    include('../user_dbconnection.php');
    session_start();
    if($_SESSION['login_user'])
      {
          $uid=$_SESSION['login_user'];
          $sql="SELECT * FROM `newuser` WHERE userid='$uid' ";
          $result1 = mysqli_query($conn,$sql);
          $data=mysqli_fetch_assoc($result1);
          $fname=$data['fname'];
          $lname=$data['lname'];
          $fullname=$fname . " " . $lname;
          $class=$data['class'];
          $section=$data['section'];
          $last_login=$data['last_login'];
         
     }

      else
      {
        header("location:../index.php");
      }

 
 ?>

 

    <div class="container-fluid">
       <div class="row">
            <div class="col-6"> 
                 
                  <div class="row">
                     <b><label for="lastlogin">Last Login: </label></b>
                     <b><?php echo " " .  $last_login ?></b>
                   </div >
            
                  <div class="row">
                     <b><label for="Name">NAME: </label></b>
                     <b><?php echo " " . $fullname ?></b>
                  </div>

                  <div class="row">
                     <b><label for="Class">CLASS: </label></b>
                     <b><?php echo " " . $class ?></b>
                  </div>

                 <div class="row">
                      <b><label for="Section">SECTION: </label></b>
                      <b><?php echo " " . $section ?></b>
                 </div>

            </div>

             <div class="col-6">
                 <div class="profilebtn offset-8 ">
                     <input type="submit" type="submit" class="btn btn-primary"  value="View Your Profile" name='profile' id="profile" onclick="return myprofile();"/>
                 </div>
            </div>

           
            
      </div>
     
  </div>

<div class="details 0ffset-5">
   <h2 align="center">STUDENTS DETAILS</h2>
</div>
            


<div class="row">

<?php
    
	
	// define how many results you want per page
    $results_per_page = 3;
    
    // find out the number of results stored in database
    $sql="SELECT * FROM `newuser` ";
    $result = mysqli_query($conn, $sql);
    $number_of_results = mysqli_num_rows($result);
   
   

    

   // determine number of total pages available
    $number_of_pages = ceil($number_of_results/$results_per_page);
 
  // determine which page number visitor is currently on
  if (!isset($_GET['page'])) {
    $page = 1;
    } else {
      $page = $_GET['page'];
      
     
     }
    
     
    
   // determine the sql LIMIT starting number for the results on the displaying page
   $this_page_first_result = ($page-1)*$results_per_page;
   $this_page_last_result= $this_page_first_result+$results_per_page;
 
   

  // retrieve selected results from database and display them on page
  $sql='SELECT * FROM `newuser` LIMIT ' . $this_page_first_result . ',' .  $results_per_page;
  $result = mysqli_query($conn, $sql);
  $data=mysqli_fetch_all($result, MYSQLI_ASSOC);
  
  $row=mysqli_num_rows($result);
  
  ?>


     
         <div class="col-md-10">
	     	<nav aria-label="Page navigation">
                  <ul class="pagination pagination-lg">
                
				          <?php for($page = 1; $page<=$number_of_pages; $page++) {?>
                                <li class="page-item">
                                    <a class="page-link" href="dashboard.php?page=<?= $page; ?>"><?= $page; ?></a>
                                </li>
                           <?php } ?>
                          
                   </ul> 
                        
				 
		   </nav>
         </div>
      
 
  <?php
   
  
  
    
    for($i=0 ;  $i<$row ;  $i++)
     { 
        
             $fname=$data[$i]['fname'];
             $lname=$data[$i]['lname'];
             $class=$data[$i]['class'];
             $section=$data[$i]['section'];
             $image=$data[$i]['image'];
        
     
     ?>
      <div class="col-sm-3">
        <div class="card">
         
           <img src="../STD_IMG/<?php echo $image;?>" class="card-img-top" alt="...">
                <div class="card-body">
                 
                    
                    <h5 class="card-title"><?php echo $fname . " " . $lname?></h5>
                    <h5 class="card-title"><?php echo "Class:" . " " . $class . " " . $section?></h5>
                    
                   <!-- <p class="card-text"></p>-->
                </div>
           
        </div>
    </div>

   <?php
     
     
     }
     
 


?>
<script src="../js/dashboard.js"></script>
<!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src=" https://code.jquery.com/jquery-3.4.1.slim.min.js " integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n " crossorigin="anonymous "></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js " integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo " crossorigin="anonymous "></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js " integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6 " crossorigin="anonymous "></script>

</body>

</div>
</body>
</html>