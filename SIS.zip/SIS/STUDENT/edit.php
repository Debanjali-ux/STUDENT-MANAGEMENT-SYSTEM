<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

<!-- <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script> -->

<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

    <title>STUDENT MANAGEMENT SYSTEM</title>
   <link href="../CSS/edit.css" rel="stylesheet" type=text/css>
</head>
<body>
<?php 
    include('../user_dbconnection.php');
    session_start();
    if($_SESSION['login_user'])
      {
        $uid=$_SESSION['login_user'];
        $sql="SELECT * FROM `newuser` WHERE userid='$uid' ";
        $result1 = mysqli_query($conn,$sql);
        $data=mysqli_fetch_assoc($result1);
        $actid=$data['id'];
      
        $fname=$data['fname'];
        $lname=$data['lname'];
        $email=$data['email'];
        $phnNo=$data['phnNo'];
        $address=$data['address'];
        $class=$data['class'];
        $section=$data['section'];
        $password=$data['Password'];
        $image=$data['image'];

         
     }

      else
      {
        header("location:../index.php");
      }

 
 ?>  
 <div class="logo"> 
            <h1 align="center">STUDENT MANAGEMENT SYSTEM</h1>
</div>

 <form method="post" enctype="multipart/form-data">
       <div class="form-group">
            <label for="fname">First Name: </label>
            <input type="text" class="form-control" id="firstName" name="firstName" value="<?php echo $fname ?>" >
            

       </div>
        
       <div class="form-group">
            <label for="lname">Last Name: </label>
            <input type="text" class="form-control" id="lastName" name="lastName" value="<?php echo $lname ?>" >

       </div>

       <div class="form-group">
            <label for="email">Email: </label>
            <input type="text" class="form-control" id="email" name="email" value="<?php echo $email ?>"  >

       </div>

       <div class="form-group">
            <label for="phnNo">Phone No: </label>
            <input type="text" class="form-control" id="phoneNo" name="phnNo" value="<?php echo $phnNo ?>" >

       </div>

       <div class="form-group">
            <label for="address">Address: </label>
            <input type="text" class="form-control" id="address"  name='address' value="<?php echo $address ?>">

       </div>

       <div class="form-row">
                <div class="form-group col-md-6">
                <label for="sclass">Class: </label>
                     <select class="form-control" id="sclass" name="sclass" value="<?php echo $class ?>">
                         <option value="" hidden>Select the Class</option>
                         <option value="1">One</option>
                         <option value="2">Two</option>
                         <option value="3">Three</option>
                         <option value="4">Four</option>
                         <option value="5">Five</option>
                    </select>
                   
                </div>
                
                <div class="form-group col-md-6">
                  <label for="ssection">Section: </label>
                    <select class="form-control" id="ssection" name="ssection" disabled>
                                    <option selected>Select the Section</option>
                                   
                    </select>
                   
                </div>
            </div>

       <div class="form-group">
            <label for="password">Password: </label>
            <input type="password" class="form-control" id="pwd" name="pwd" value="Enter new password" >
          <small id="emailHelp" class="form-text text-muted"><b>Password must contain atleast one upper case letter,atleast one number and atleast
                   eight characters long.</b></small>
       </div>

       <div class="form-group">
            <label for="confirmpassword">Confirm Password: </label>
            <input type="password" class="form-control" id="confirmPwd" name="confirmPwd" value="Enter new password">
           
       </div>

       <div class="form-group col-md-6">
            <label for="img"><b>Upload image:</b></label>&nbsp;
            <input type="file"  id="img" name="img"><br>

       </div>
       
      
       <input type="submit" class="btn btn-primary" onclick="return register();" value="Submit" name='submit' id="submit"/>
</form>





<script src="../js/edit.js"></script>
<script src="../js/custom.js"></script>
<!-- Optional JavaScript -->
   

</body>
 </html>

 <?php
   $filename="";
   $extension="";
   if($_SERVER["REQUEST_METHOD"]=="POST")
     {
     
      $fname=$_POST['firstName'];
      
      $lname=$_POST['lastName'];
      $email=$_POST['email'];
      $phnNo=$_POST['phnNo'];
      $address=$_POST['address'];
      $pwd=md5($_POST['pwd']);
      $confirmPwd=md5($_POST['confirmPwd']);
      $class=$_POST['sclass'];
      $section=$_POST['ssection'];
      $imagename=$_FILES['img']['name'];
      $tempname=$_FILES['img']['tmp_name'];
      $file=explode(".",$imagename);
      $fileSize= $_FILES['img']['size'] ;
      if( $fileSize!=0)
      {   
         
          $filename=$file[0];
          $extension=$file[1];
      }
      
      $allowedExtensions=array("gif","png","bmp","jpeg","jpg");
      
      

     include('../user_dbconnection.php');
     
     $sql1="SELECT * FROM `newuser` WHERE email='$email' and phnNo='$phnNo' and id<>'$actid'";
     $result1=mysqli_query($conn,$sql1);
     $run1=mysqli_num_rows( $result1);
     $sql2="SELECT * FROM `newuser` WHERE email='$email' and id<>'$actid'";
     $result2=mysqli_query($conn,$sql2);
     $run2=mysqli_num_rows( $result2);
     $sql3="SELECT * FROM `newuser` WHERE  phnNo='$phnNo' and id<>'$actid'";
     $result3=mysqli_query($conn,$sql3);
     $run3=mysqli_num_rows( $result3);
     
     if($run1==1)
     {
       ?>
       <script>
           alert("The email and Phone number already exists...Please try to register with new email and number!!!");
       </script>
       <?php
     }
     else if($run2==1)
     {
       ?>
       <script>
           alert("The email already exists...Please try to register with a new email!!!");
       </script>
       <?php
     }
     else if($run3==1)
     {
       ?>
       <script>
           alert("The Phone Number already exists...Please try to register with a new number!!!");
       </script>
       <?php
     }


     else{
         
   if(preg_match("/^[A-Za-z]+$/",$_POST['firstName']))
     {  

        if(preg_match("/^[A-Za-z]+$/",$_POST['lastName']))
          {
             if(preg_match("/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/",$_POST['email']))
               {
                if(preg_match("/^(?:(?:\+|0{0,2})91(\s*[\ -]\s*)?|[0]?)?[789]\d{9}|(\d[ -]?){10}\d$/",$_POST['phnNo']))   
                   {
                    if(preg_match("/.+$/",$_POST['address']))
                        { 
                         if($_POST['sclass']!="")
                         {
                          if($_POST['ssection']!="select")
                           {
                               if(preg_match("/^(?=.*?[A-Z])(?=.*?[0-9]).{8,}$/",$_POST['pwd']))
                            {
                                if($_POST['confirmPwd']==$_POST['pwd'])
                               {  
                                  
                                 if(in_array($extension,$allowedExtensions))
                                   {  
                                       $userid="STU" . $phnNo;
                                       move_uploaded_file($tempname,"../STD_IMG/$imagename");
                                      
                                      $sql1="UPDATE NEWUSER SET userid='$userid',fname='$fname',lname='$lname',email='$email',phnNo='$phnNo',address='$address'
                                      ,class='$class',section='$section',Password='$pwd',image='$imagename'
                                       where id='$actid'";
                                       $result = mysqli_query($conn,$sql1);
                                      
                                       ?>
                                       <script>
                                          alert("Successfully Updated");
                                          //window.location.href="../index.php";
                                       </script>
                                       <?php
                                   }}
                                }
                            }
                        }
                   }
               }
          }
     }}
    }}

 
?>
 
